package com.example.demo.Model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

import org.mindrot.jbcrypt.BCrypt;

public class User {

  private int id;

  @NotNull(message = "First name is required")
  private String firstName;

  @NotBlank(message = "Last name is required")
  private String lastName;

  @NotBlank(message = "Password is required")
  private String password;

  @NotNull(message = "Username is required")
  private String username;
  private long account_created;
  private long account_updated;

  public User(int identity, String fn, String ln, String p, String u) {
    this.id = identity;
    this.firstName = fn;
    this.lastName = ln;
    this.password = BCrypt.hashpw(p, BCrypt.gensalt());
    this.username = u;
    this.account_created = System.currentTimeMillis();
    this.account_updated = System.currentTimeMillis();
  }

  public int getId() {
    return id;
  }

  public void setId(int id) {
    this.id = id;
  }

  public String getFirstName() {
    return firstName;
  }

  public String getLastName() {
    return lastName;
  }

  public String getUsername() {
    return username;
  }

  public void setAccount_updated(long account_updated) {
    this.account_updated = account_updated;
  }

  public long getAccount_updated() {
    return account_updated;
  }

  public long getAccount_created() {
    return account_created;
  }

  public boolean verifyPassword(String checkPassword) {
    BCryptPasswordEncoder encoder = new BCryptPasswordEncoder();
    return encoder.matches(checkPassword, this.password);
  }

  @JsonIgnore
  public String getPassword() {
    return password;
  }

}
