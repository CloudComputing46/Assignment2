package com.example.demo;

import com.example.demo.Model.UserStore;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;

@Configuration
@EnableWebSecurity
public class SecurityConfig {

  /**
   * Defines the security filter chain.
   */
  @Bean
  public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
    http
        // Disable CSRF for basic auth
        .csrf(csrf -> csrf.disable())
        .authorizeHttpRequests(auth -> auth
            // Allow user creation without authentication
            .requestMatchers(HttpMethod.POST, "/v1/user").permitAll()
            // Allow health check without authentication
            .requestMatchers("/healthz").permitAll()
            // Require authentication for the GET request to retrieve user data
            .requestMatchers(HttpMethod.GET, "/v1/user/**").authenticated()
            // Deny everything else
            .anyRequest().denyAll()
        )
        // Enable HTTP Basic authentication
        .httpBasic(httpBasic -> {});

    return http.build();
  }

  /**
   * Custom UserDetailsService to load user details from the UserStore.
   */
  @Bean
  public UserDetailsService userDetailsService() {
    return username -> {
      com.example.demo.Model.User user = UserStore.getUser(username);
      if (user == null) {
        throw new UsernameNotFoundException("User not found: " + username);
      }

      // Return a Spring Security UserDetails object, using the HASHED password.
      return User.builder()
          .username(user.getUsername())
          .password(user.getPassword()) // Now works because of the new getter
          .roles("USER")
          .build();
    };
  }

  /**
   * Defines the BCryptPasswordEncoder bean used by Spring Security for comparison.
   */
  @Bean
  public PasswordEncoder passwordEncoder() {
    // This encoder will compare the password from the request against the hash
    // retrieved by the UserDetailsService.
    return new BCryptPasswordEncoder();
  }
}