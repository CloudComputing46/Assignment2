package com.example.demo.Controller;

import jakarta.validation.Valid;
import java.util.*;

import com.example.demo.Model.User;
import java.util.Map;

import java.util.concurrent.atomic.AtomicInteger;
import org.springframework.web.bind.annotation.*;
import org.springframework.http.ResponseEntity;

import com.example.demo.Model.UserStore;

@RestController
@RequestMapping("/v1/user")
public class UserController {
  private static AtomicInteger id = new AtomicInteger(1);
  //private static Map<String, User> users = new HashMap<>();

  @PostMapping
  public ResponseEntity<?> createUser(@Valid @RequestBody User newUser) {
    int newId = id.getAndIncrement();

    //verifying if the username is an email
    if (!newUser.getUsername().contains("@") || !newUser.getUsername().contains(".com")) {
      return ResponseEntity.status(400).body("Username must be a valid email address");
    }

    newUser.setId(newId);
    UserStore.addUser(newUser.getUsername(), newUser);

    return ResponseEntity.status(201).body(UserStore.getUser(newUser.getUsername()));
  }
}
